PRACTICAL 7 - SIMPLE OUTPUT

Structure:
practical7_simple_output/
  lib/main.dart
  pubspec.yaml
  README.txt

Open this folder in Android Studio, then run:
flutter pub get
flutter run -d chrome

Simple screen: device names, ON/OFF switches, sliders, and a button to show active devices.
