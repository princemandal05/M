import 'package:flutter/material.dart';

void main() {
  runApp(const MaterialApp(
    debugShowCheckedModeBanner: false,
    home: DevicePage(),
  ));
}

// Device details
class Device {
  String name;
  bool isOn;
  double value;

  Device(this.name, this.isOn, this.value);
}

class DevicePage extends StatefulWidget {
  const DevicePage({super.key});

  @override
  State<DevicePage> createState() => _DevicePageState();
}

class _DevicePageState extends State<DevicePage> {
  // List of devices
  final List<Device> devices = [
    Device('Living Room Light', true, 75),
    Device('AC Temperature', true, 22),
    Device('Smart Speaker', false, 40),
    Device('Balcony Lights', false, 100),
  ];

  // Show devices that are ON
  void showSelected() {
    final active = devices.where((d) => d.isOn).toList();

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Active Devices'),
        content: Text(active.isEmpty
            ? 'No devices are ON'
            : active.map((d) => '${d.name}: ${d.value.round()}').join('\n')),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('OK'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Smart Devices')),
      body: ListView(
        children: [
          // Each device row
          for (int i = 0; i < devices.length; i++) ...[
            ListTile(
              title: Text(devices[i].name),
              subtitle: Text(devices[i].isOn ? 'ON' : 'OFF'),
              // Switch: ON/OFF controller
              trailing: Switch(
                value: devices[i].isOn,
                onChanged: (value) {
                  setState(() => devices[i].isOn = value);
                },
              ),
            ),
            // Slider: value controller
            Slider(
              min: 0,
              max: 100,
              value: devices[i].value.clamp(0, 100),
              onChanged: (value) {
                setState(() => devices[i].value = value);
              },
            ),
            const Divider(height: 1),
          ],
        ],
      ),
      // Button: show active devices
      floatingActionButton: FloatingActionButton(
        onPressed: showSelected,
        child: const Icon(Icons.check),
      ),
    );
  }
}
