PRACTICAL 12 - FULL CODE + WHAT TO DELETE FOR EACH GESTURE

AIM
Implement single tap, double tap, long press, and dragging in Flutter.

FILES
- lib/main.dart: Full code with all four gestures included.
- pubspec.yaml: Flutter project configuration.
- This guide: Exact code parts to remove if you need to demonstrate only one gesture.

RUN THE FULL PROJECT
1. Extract the ZIP.
2. Open the folder in VS Code or Android Studio.
3. Open terminal in the project folder.
4. Run: flutter create .
5. Run: flutter pub get
6. Run: flutter run

FULL APP
The full code includes all four gesture callbacks:
- onTap = single tap
- onDoubleTap = double tap
- onLongPress = long press
- onPanUpdate + onPanEnd = drag

IMPORTANT: HOW TO KEEP ONLY ONE GESTURE
Open lib/main.dart. In the GestureDetector, remove the callbacks you do not need.
Also remove the state variables/widgets used only for dragging when applicable.

A) ONLY SINGLE TAP
KEEP:
- onTap callback.
DELETE:
- Entire onDoubleTap callback.
- Entire onLongPress callback.
- Entire onPanUpdate callback.
- Entire onPanEnd callback.
- Delete: Offset _dragOffset = Offset.zero;
- Replace:
    child: Transform.translate(
      offset: _dragOffset,
      child: GestureDetector(
        ...
      ),
    ),
  with:
    child: GestureDetector(
      ...
    ),
  (Keep the GestureDetector and Container.)
- Keep _lastGesture and _boxColor because onTap changes them.

B) ONLY DOUBLE TAP
KEEP:
- onDoubleTap callback.
DELETE:
- Entire onTap callback.
- Entire onLongPress callback.
- Entire onPanUpdate callback.
- Entire onPanEnd callback.
- Delete: Offset _dragOffset = Offset.zero;
- Remove Transform.translate as described in section A.
- Keep _lastGesture and _boxColor.

C) ONLY LONG PRESS
KEEP:
- onLongPress callback.
DELETE:
- Entire onTap callback.
- Entire onDoubleTap callback.
- Entire onPanUpdate callback.
- Entire onPanEnd callback.
- Delete: Offset _dragOffset = Offset.zero;
- Remove Transform.translate as described in section A.
- Keep _lastGesture and _boxColor.

D) ONLY DRAG
KEEP:
- onPanUpdate callback.
- onPanEnd callback.
DELETE:
- Entire onTap callback.
- Entire onDoubleTap callback.
- Entire onLongPress callback.
KEEP:
- Offset _dragOffset = Offset.zero;
- Transform.translate, because it moves the box.
- _lastGesture and _boxColor (the box color stays at its starting color).

E) ONLY TAP ANYWHERE (WHOLE SCREEN)
The provided practical code detects gestures on the box, not anywhere on the screen.
To detect a tap anywhere, wrap the page body with a GestureDetector and use behavior: HitTestBehavior.opaque. This is a separate adjustment and is not part of the original box-only code.

REMEMBER
- Delete a whole callback from its opening line (for example, onDoubleTap: () {) through its closing `},`.
- Do not delete the commas or braces belonging to neighboring callbacks.
- Save the file and run: flutter run
