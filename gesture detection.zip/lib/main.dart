import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Practical 12',
      home: const GesturesScreen(),
    );
  }
}

class GesturesScreen extends StatefulWidget {
  const GesturesScreen({super.key});

  @override
  State<GesturesScreen> createState() => _GesturesScreenState();
}

class _GesturesScreenState extends State<GesturesScreen> {
  String _lastGesture = 'None';
  Color _boxColor = Colors.deepPurple;
  Offset _dragOffset = Offset.zero;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Gestures Demo')),
      body: Stack(
        children: [
          // Displays the last gesture.
          Positioned(
            top: 40,
            left: 0,
            right: 0,
            child: Text(
              'Last Detected Gesture:\n$_lastGesture',
              textAlign: TextAlign.center,
              style: const TextStyle(
                fontSize: 22,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
          Center(
            child: Transform.translate(
              offset: _dragOffset,
              child: GestureDetector(
                // SINGLE TAP: tap the box once.
                onTap: () {
                  setState(() {
                    _lastGesture = 'Single Tap';
                    _boxColor = Colors.blue;
                  });
                },

                // DOUBLE TAP: tap the box twice quickly.
                onDoubleTap: () {
                  setState(() {
                    _lastGesture = 'Double Tap';
                    _boxColor = Colors.green;
                  });
                },

                // LONG PRESS: press and hold the box.
                onLongPress: () {
                  setState(() {
                    _lastGesture = 'Long Press';
                    _boxColor = Colors.red;
                  });
                },

                // DRAG: move the box with your finger/mouse.
                onPanUpdate: (details) {
                  setState(() {
                    _lastGesture = 'Dragging...';
                    _dragOffset += details.delta;
                  });
                },

                // Runs when dragging stops.
                onPanEnd: (details) {
                  setState(() {
                    _lastGesture = 'Drag Ended';
                  });
                },

                child: Container(
                  width: 150,
                  height: 150,
                  decoration: BoxDecoration(
                    color: _boxColor,
                    borderRadius: BorderRadius.circular(16),
                  ),
                  child: const Center(
                    child: Text(
                      'Interact Me',
                      style: TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
