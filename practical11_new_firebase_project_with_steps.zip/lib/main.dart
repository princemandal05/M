import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

// This file is created for YOUR new Firebase project by `flutterfire configure`.
// Follow README.txt first, then this import will be available.
import 'firebase_options.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // Connect the app to your Firebase project.
  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );

  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Practical 11',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.deepPurple),
        useMaterial3: true,
      ),
      home: const AddStudentPage(),
    );
  }
}

class AddStudentPage extends StatefulWidget {
  const AddStudentPage({super.key});

  @override
  State<AddStudentPage> createState() => _AddStudentPageState();
}

class _AddStudentPageState extends State<AddStudentPage> {
  // Controller for the Name field.
  final TextEditingController _nameController = TextEditingController();

  // Controller for the Age field.
  final TextEditingController _ageController = TextEditingController();

  @override
  void dispose() {
    // Release controllers when the page is closed.
    _nameController.dispose();
    _ageController.dispose();
    super.dispose();
  }

  // Validate and insert the student record in Firestore.
  Future<void> _addStudent() async {
    final String name = _nameController.text.trim();
    final int? age = int.tryParse(_ageController.text.trim());

    // Check that name and age are valid.
    if (name.isEmpty || age == null || age <= 0) {
      _showMessage('Error', 'Please enter a valid name and age.');
      return;
    }

    try {
      // Adds a document to the "students" collection.
      await FirebaseFirestore.instance.collection('students').add({
        'name': name,
        'age': age,
        'createdAt': FieldValue.serverTimestamp(),
      });

      _showMessage('Success', 'Student added successfully.');
      _nameController.clear();
      _ageController.clear();
    } catch (e) {
      _showMessage('Error', e.toString());
    }
  }

  // Displays success or error message.
  void _showMessage(String title, String message) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(title),
        content: Text(message),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('OK'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Add Student'),
        backgroundColor: Theme.of(context).colorScheme.inversePrimary,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            // Student name input.
            TextField(
              controller: _nameController,
              decoration: const InputDecoration(
                labelText: 'Name',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 12),

            // Student age input.
            TextField(
              controller: _ageController,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(
                labelText: 'Age',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 24),

            // Button to save the student details.
            ElevatedButton(
              onPressed: _addStudent,
              child: const Text('Add Student'),
            ),
          ],
        ),
      ),
    );
  }
}
