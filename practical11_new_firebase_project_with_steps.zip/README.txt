PRACTICAL 11 - FIRESTORE DATA INSERTION
BEGINNER SETUP GUIDE (NEW FIREBASE PROJECT)

AIM
Create a new Firebase project, connect it to Flutter, and save a student's name and age in Cloud Firestore.

APP FILES
- lib/main.dart: Flutter UI and Firestore insertion code.
- pubspec.yaml: Required Flutter packages.
- lib/firebase_options.dart: Generated for your Firebase project during setup; it is not included in this ZIP.

PART 1 - CREATE A NEW FIREBASE PROJECT
1. Open a browser and go to https://console.firebase.google.com/
2. Sign in with your Google account.
3. Click "Create a project" or "Add project".
4. Enter a project name, for example: practical11-student-app.
5. Click Continue and follow the setup screens.
6. If Google Analytics is offered, you can turn it off for this basic practical if you do not need it.
7. Click "Create project".
8. When the project is ready, click Continue to open the Firebase project dashboard.

PART 2 - CREATE CLOUD FIRESTORE DATABASE
9. In the left menu, open Build > Firestore Database.
10. Click "Create database".
11. Select Standard edition, then click Next.
12. Choose a database location. Choose carefully because the location cannot be changed later.
13. Select the security mode requested by your teacher. If using test mode for a classroom demonstration, remember it is temporary and permits broad access; do not use test mode for a real app.
14. Click Create and wait for the database to be ready.

PART 3 - OPEN THE FLUTTER PROJECT
15. Extract the ZIP file.
16. Open the extracted folder in VS Code or Android Studio.
17. Open Terminal in the project folder.
18. Run:
    flutter create .
19. Then run:
    flutter pub get

PART 4 - INSTALL AND CONFIGURE FIREBASE TOOLS
20. Check that Node.js and npm are installed. If they are not installed, install Node.js first.
21. Install Firebase CLI:
    npm install -g firebase-tools
22. Sign in to Firebase:
    firebase login
23. Install FlutterFire CLI:
    dart pub global activate flutterfire_cli
24. From the same Flutter project folder, run:
    flutterfire configure
25. Select the NEW Firebase project you created in Part 1.
26. Select the platform you will run (for example, Android).
27. Wait for the command to finish. It creates lib/firebase_options.dart.
28. The app already imports this generated file. Do not paste Firebase keys into main.dart.

PART 5 - RUN THE APP
29. Start an Android emulator or connect your phone with USB debugging enabled.
30. Run:
    flutter run
31. If asked to choose a device, select your emulator or connected phone.

PART 6 - INSERT AND VERIFY STUDENT DATA
32. In the app, enter a student's name.
33. Enter a positive age, for example 20.
34. Tap "Add Student".
35. The app should show "Student added successfully".
36. Return to Firebase Console > Firestore Database > Data.
37. Open the "students" collection. The first insertion creates this collection automatically.
38. Open the document to view the name, age, and createdAt fields.

HOW THE CODE WORKS
- _nameController reads the Name field.
- _ageController reads the Age field.
- _addStudent() validates the values and inserts them.
- collection('students') selects the collection.
- add({...}) creates a new document with an automatically generated ID.
- FieldValue.serverTimestamp() stores the server timestamp.

COMMON ISSUES
- "Target of URI doesn't exist: firebase_options.dart": Run `flutterfire configure` from the project folder and ensure it completes.
- Firebase CLI not found: Check that Node.js/npm are installed and reopen the terminal after installation.
- Permission denied: Check the Firestore rules and the security mode configured in Firebase Console.
- App cannot find a device: Start an emulator or connect a phone.

IMPORTANT
This ZIP contains the Flutter source code and setup guide. Firebase configuration is unique to your new Firebase project, so `firebase_options.dart` is generated on your computer during Part 4.
