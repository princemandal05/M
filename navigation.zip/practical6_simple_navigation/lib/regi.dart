import 'package:flutter/material.dart';

class RegiPage extends StatefulWidget {
  const RegiPage({super.key});

  @override
  State<RegiPage> createState() => _RegiPageState();
}

class _RegiPageState extends State<RegiPage> {
  String gender = 'Male';
  final List<String> hobbies = [];

  @override
  Widget build(BuildContext context) {
    final username = ModalRoute.of(context)!.settings.arguments as String;

    return Scaffold(
      appBar: AppBar(title: Text('Registration Form Hello $username!')),
      body: Padding(
        padding: const EdgeInsets.all(15),
        child: ListView(
          children: [
            const TextField(
              decoration: InputDecoration(labelText: 'Full Name'),
            ),
            const TextField(
              decoration: InputDecoration(labelText: 'Email Address'),
            ),
            const TextField(
              decoration: InputDecoration(labelText: 'Mobile Number'),
            ),
            const Text('Gender'),
            RadioListTile<String>(
              title: const Text('Male'),
              value: 'Male',
              groupValue: gender,
              onChanged: (value) => setState(() => gender = value!),
            ),
            RadioListTile<String>(
              title: const Text('Female'),
              value: 'Female',
              groupValue: gender,
              onChanged: (value) => setState(() => gender = value!),
            ),
            const Text('Hobbies'),
            ...['Reading', 'Music', 'Gaming', 'Sports'].map(
              (hobby) => CheckboxListTile(
                title: Text(hobby),
                value: hobbies.contains(hobby),
                onChanged: (value) {
                  setState(() {
                    if (value == true) {
                      hobbies.add(hobby);
                    } else {
                      hobbies.remove(hobby);
                    }
                  });
                },
              ),
            ),
            ElevatedButton(
              onPressed: () {},
              child: const Text('Submit Details'),
            ),
          ],
        ),
      ),
    );
  }
}
