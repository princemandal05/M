PRACTICAL 6 - SIMPLE FLUTTER NAVIGATION

This ZIP has a single project folder with the usual basic Flutter source layout:
- pubspec.yaml
- lib/main.dart
- lib/login.dart
- lib/regi.dart

HOW TO RUN
1. Extract the ZIP.
2. Open the extracted practical6_simple_navigation folder directly in Android Studio.
   Select the folder containing pubspec.yaml.
3. Open Terminal in that folder and run:
   flutter pub get
   flutter run -d chrome

DEMO LOGIN
Username: abc
Password: 123
