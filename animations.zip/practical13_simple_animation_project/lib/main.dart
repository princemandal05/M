import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: const AnimationPage(),
    );
  }
}

class AnimationPage extends StatefulWidget {
  const AnimationPage({super.key});

  @override
  State<AnimationPage> createState() => _AnimationPageState();
}

class _AnimationPageState extends State<AnimationPage>
    with SingleTickerProviderStateMixin {
  // Implicit animation values
  double boxSize = 100;
  Color boxColor = Colors.blue;

  // Tween animation value
  double tweenSize = 100;

  // Explicit animation controller
  late AnimationController controller;
  late Animation<double> widthAnimation;

  @override
  void initState() {
    super.initState();

    // Explicit animation: controller and width tween
    controller = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 2),
    );

    widthAnimation = Tween<double>(begin: 100, end: 250).animate(controller);
  }

  @override
  void dispose() {
    controller.dispose(); // Stop controller when page closes
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Practical 13 - Animation')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            // 1) Implicit Animation: AnimatedContainer
            const Text('1. Implicit Animation'),
            const SizedBox(height: 10),
            AnimatedContainer(
              duration: const Duration(seconds: 2),
              curve: Curves.bounceIn,
              width: boxSize,
              height: 100,
              color: boxColor,
            ),
            ElevatedButton(
              onPressed: () {
                setState(() {
                  boxSize = boxSize == 100 ? 200 : 100;
                  boxColor =
                      boxColor == Colors.blue ? Colors.orange : Colors.blue;
                });
              },
              child: const Text('Change Box'),
            ),

            const Divider(height: 35),

            // 2) Tween Animation: TweenAnimationBuilder
            const Text('2. Tween Animation'),
            const SizedBox(height: 10),
            TweenAnimationBuilder<double>(
              tween: Tween<double>(begin: 100, end: tweenSize),
              duration: const Duration(seconds: 1),
              builder: (context, value, child) {
                return Container(
                  width: value,
                  height: 80,
                  color: Colors.amber,
                );
              },
            ),
            ElevatedButton(
              onPressed: () {
                setState(() {
                  tweenSize = tweenSize == 100 ? 250 : 100;
                });
              },
              child: const Text('Animate Tween Box'),
            ),

            const Divider(height: 35),

            // 3) Explicit Animation: AnimationController + Tween
            const Text('3. Explicit Animation'),
            const SizedBox(height: 10),
            AnimatedBuilder(
              animation: controller,
              builder: (context, child) {
                return Container(
                  width: widthAnimation.value,
                  height: 80,
                  color: Colors.green,
                );
              },
            ),
            ElevatedButton(
              onPressed: () {
                if (controller.status == AnimationStatus.completed) {
                  controller.reverse();
                } else {
                  controller.forward(from: 0);
                }
              },
              child: const Text('Start Explicit Animation'),
            ),
          ],
        ),
      ),
    );
  }
}
