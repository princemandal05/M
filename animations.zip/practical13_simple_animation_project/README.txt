# Practical 13 - Simple Animation Project

This is a short, simple Flutter project containing all 3 animations from Practical 13:
1. Implicit animation using `AnimatedContainer`
2. Tween animation using `TweenAnimationBuilder`
3. Explicit animation using `AnimationController`, `Tween`, and `AnimatedBuilder`

## Run the project
1. Extract the ZIP.
2. Open the `practical13_simple_animation` folder in VS Code or Android Studio.
3. Open the terminal in that folder.
4. Run:
   ```bash
   flutter pub get
   flutter run
   ```
5. Tap each button to see its animation.

## If you want only ONE animation

Keep the shared app setup at the top (`main()`, `MyApp`, and `MaterialApp`). In `AnimationPage`, keep only the section you need.

### Only Implicit Animation
- Keep the `boxSize` and `boxColor` variables.
- In `build()`, keep only the section marked `1) Implicit Animation`.
- Delete the Tween section marked `2) Tween Animation`.
- Delete the Explicit section marked `3) Explicit Animation`.
- Remove `with SingleTickerProviderStateMixin` from the state class.
- Delete `controller`, `widthAnimation`, `initState()`, and `dispose()`.

### Only Tween Animation
- Keep `tweenSize`.
- In `build()`, keep only the section marked `2) Tween Animation`.
- Delete the Implicit section marked `1) Implicit Animation`.
- Delete the Explicit section marked `3) Explicit Animation`.
- Remove `with SingleTickerProviderStateMixin` from the state class.
- Delete `boxSize`, `boxColor`, `controller`, `widthAnimation`, `initState()`, and `dispose()`.

### Only Explicit Animation
- Keep `controller` and `widthAnimation`.
- Keep `with SingleTickerProviderStateMixin` on the state class.
- Keep `initState()` and `dispose()`.
- In `build()`, keep only the section marked `3) Explicit Animation`.
- Delete the Implicit section marked `1) Implicit Animation`.
- Delete the Tween section marked `2) Tween Animation`.
- Delete `boxSize`, `boxColor`, and `tweenSize`.

## Notes
- All three examples are in `lib/main.dart`.
- The comments show where each animation begins and what the controller is for.
- If you remove a section, also remove its unused variables as listed above.
