PRACTICAL 9 - SIMPLE FORM VALIDATION

Structure:
practical9_simple_project/
  lib/
    main.dart
  pubspec.yaml
  README.txt

Run:
1. Open this folder in Android Studio.
2. Run: flutter pub get
3. Run: flutter run

The app has Name, Email, and Password fields with simple validation.
Comments identify each field/controller and the submit function.
