PRACTICAL 8 - SIMPLE URL NAVIGATION

Project structure:
practical8_simple_project/
  lib/
    main.dart
  pubspec.yaml
  README.txt

Run:
1. Open this folder in Android Studio.
2. In Terminal, run: flutter pub get
3. Run the app on a device or Chrome.

The app has one button to open a YouTube search for the Sholay title track
and one clickable text link to Sholay soundtrack information.
