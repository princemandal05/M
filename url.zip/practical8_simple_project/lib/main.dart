import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

void main() {
  runApp(const MaterialApp(
    debugShowCheckedModeBanner: false,
    home: UrlPage(),
  ));
}

class UrlPage extends StatelessWidget {
  const UrlPage({super.key});

  // Opens a link in the browser or its external app
  Future<void> openLink(String link) async {
    final url = Uri.parse(link);
    await launchUrl(url, mode: LaunchMode.externalApplication);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('URL Navigation')),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            // Button: opens the Sholay title-track search on YouTube
            ElevatedButton(
              onPressed: () => openLink(
                'https://www.youtube.com/results?search_query=Sholay+title+track',
              ),
              child: const Text('Open Sholay Title Track'),
            ),
            const SizedBox(height: 20),

            // Clickable text: opens information about Sholay music
            InkWell(
              onTap: () => openLink(
                'https://en.wikipedia.org/wiki/Sholay_(soundtrack)',
              ),
              child: const Text(
                'Tap here to read about Sholay Music',
                style: TextStyle(
                  color: Colors.blue,
                  decoration: TextDecoration.underline,
                  fontSize: 16,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
