import 'package:flutter/material.dart';

class RegistrationPage extends StatefulWidget {
  const RegistrationPage({super.key});

  @override
  State<RegistrationPage> createState() => _RegistrationPageState();
}

class _RegistrationPageState extends State<RegistrationPage> {
  final name = TextEditingController();
  final email = TextEditingController();
  final mobile = TextEditingController();

  String gender = 'Male';
  List<String> hobbies = [];

  @override
  void dispose() {
    name.dispose();
    email.dispose();
    mobile.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Registration Page')),
      body: Padding(
        padding: const EdgeInsets.all(15),
        child: ListView(
          children: [
            // Name field
            TextField(
              controller: name,
              decoration: const InputDecoration(
                labelText: 'Full Name',
              ),
            ),

            // Email field
            TextField(
              controller: email,
              decoration: const InputDecoration(
                labelText: 'Email',
              ),
            ),

            // Mobile field
            TextField(
              controller: mobile,
              decoration: const InputDecoration(
                labelText: 'Mobile Number',
              ),
            ),

            // Gender selection
            const Text('Gender'),

            RadioListTile<String>(
              title: const Text('Male'),
              value: 'Male',
              groupValue: gender,
              onChanged: (v) => setState(() => gender = v!),
            ),

            RadioListTile<String>(
              title: const Text('Female'),
              value: 'Female',
              groupValue: gender,
              onChanged: (v) => setState(() => gender = v!),
            ),

            // Hobbies selection
            const Text('Hobbies'),

            ...['Reading', 'Music', 'Gaming', 'Sports'].map(
                  (h) => CheckboxListTile(
                title: Text(h),
                value: hobbies.contains(h),
                onChanged: (v) {
                  setState(() {
                    if (v == true) {
                      hobbies.add(h);
                    } else {
                      hobbies.remove(h);
                    }
                  });
                },
              ),
            ),

            // Submit button
            ElevatedButton(
              onPressed: () {
                showDialog(
                  context: context,
                  builder: (context) => AlertDialog(
                    title: const Text('Registration Details'),
                    content: Text(
                      'Name: ${name.text}\n'
                          'Email: ${email.text}\n'
                          'Mobile: ${mobile.text}\n'
                          'Gender: $gender\n'
                          'Hobbies: ${hobbies.join(", ")}',
                    ),
                    actions: [
                      TextButton(
                        onPressed: () => Navigator.pop(context),
                        child: const Text('OK'),
                      ),
                    ],
                  ),
                );
              },
              child: const Text('Submit'),
            ),
          ],
        ),
      ),
    );
  }
}