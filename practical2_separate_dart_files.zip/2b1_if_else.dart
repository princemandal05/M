void main() {
  int age = 18;
  String name = "Shriti";

  if (age >= 18) {
    print("$name enjoy your ride");
  } else {
    print("Age must be above 18");
  }
}
