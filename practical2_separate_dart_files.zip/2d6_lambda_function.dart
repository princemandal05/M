void main() {
  var multiply = (int a, int b) => a * b;

  print("Multiplication = ${multiply(5, 4)}");
}
