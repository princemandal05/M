int calculateSum() {
  int a = 15;
  int b = 25;
  return a + b;
}

void main() {
  int result = calculateSum();
  print("Sum = $result");
}
