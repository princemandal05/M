void main() {
  int secretNumber = 5;
  int guess = 3;

  do {
    print("You guessed: $guess");
    guess++;
  } while (guess != secretNumber);

  print("You found the secret number: $secretNumber");
}
