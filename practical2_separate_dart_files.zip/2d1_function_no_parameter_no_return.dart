void greet() {
  print("Hello, Welcome to Dart!");
}

void main() {
  greet();
}
