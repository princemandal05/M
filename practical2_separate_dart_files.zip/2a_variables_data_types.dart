void main() {
  int age = 20;
  double height = 5.8;
  String name = "Aditi";
  bool isStudent = true;

  print("Name: $name");
  print("Age: $age");
  print("Height: $height");
  print("Student: $isStudent");
}
