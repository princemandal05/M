PRACTICAL 2 - BASICS OF DART PROGRAMMING
Each program is saved in its own .dart file.

Files:
- 2a_variables_data_types.dart
- 2b1_if_else.dart
- 2b2_if_else_if_else.dart
- 2b3_switch_case.dart
- 2c1_for_loop.dart
- 2c2_while_loop.dart
- 2c3_do_while_loop.dart
- 2d1_function_no_parameter_no_return.dart
- 2d2_function_parameter_no_return.dart
- 2d3_function_parameter_return.dart
- 2d4_function_no_parameter_return.dart
- 2d5_recursive_function.dart
- 2d6_lambda_function.dart

Run any file using:
  dart filename.dart

For example:
  dart 2a_variables_data_types.dart

The examples are based on the uploaded Practical 2 document, with small readability fixes where needed.
