PRACTICAL 14 - IMPLEMENTING PACKAGES IN FLUTTER
Simple project with a custom calculator package and a Flutter app.

FOLDER STRUCTURE
practical14_simple_package_project/
  my_calculator/       <- Dart package
  calculator_app/      <- Flutter app that uses the package

STEP-BY-STEP (Windows / Android Studio or VS Code)

1. Extract this ZIP.
2. Open the extracted practical14_simple_package_project folder in Android Studio or VS Code.
3. Open Terminal / Command Prompt in the extracted folder.
4. Enter the package folder and get dependencies:
      cd my_calculator
      flutter pub get
5. Run the package test:
      flutter test
   The test checks that 20 + 3 equals 23.
6. Go back to the main folder:
      cd ..
7. Enter the Flutter app folder and get dependencies:
      cd calculator_app
      flutter pub get
8. Start an emulator or connect your phone, then run:
      flutter run

EXPECTED OUTPUT
20 + 3 = 23

HOW THE FILES WORK
- my_calculator/lib/src/calculator.dart: add, subtract, multiply, divide functions.
- my_calculator/lib/my_calculator.dart: exports the Calculator class.
- calculator_app/pubspec.yaml: connects the app to the local package using path: ../my_calculator.
- calculator_app/lib/main.dart: imports the package and displays the addition result.
- my_calculator/test/my_calculator_test.dart: simple package test.

IMPORTANT
Keep both folders (my_calculator and calculator_app) next to each other. Do not move either folder alone, because the local package path depends on this structure.
