import 'package:flutter_test/flutter_test.dart';
import 'package:my_calculator/my_calculator.dart';

void main() {
  test('addition works', () {
    final calc = Calculator();
    expect(calc.add(20, 3), 23);
  });
}
