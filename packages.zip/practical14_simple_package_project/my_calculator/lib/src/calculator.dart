// Calculator functions used by the package.
class Calculator {
  int add(int a, int b) => a + b;
  int sub(int a, int b) => a - b;
  int mul(int a, int b) => a * b;

  double div(int a, int b) {
    if (b == 0) {
      throw ArgumentError('Division by zero is not allowed');
    }
    return a / b;
  }
}
