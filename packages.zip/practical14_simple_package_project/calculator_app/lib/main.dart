import 'package:flutter/material.dart';
import 'package:my_calculator/my_calculator.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    final calc = Calculator(); // Use the package class
    final result = calc.add(20, 3); // Perform addition

    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Scaffold(
        body: Center(
          child: Text(
            '20 + 3 = $result',
            style: const TextStyle(fontSize: 24),
          ),
        ),
      ),
    );
  }
}
