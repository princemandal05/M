import 'package:flutter/material.dart';

class RegistrationPage extends StatefulWidget {
  const RegistrationPage({super.key});

  @override
  State<RegistrationPage> createState() => _RegistrationPageState();
}

class _RegistrationPageState extends State<RegistrationPage> {
  final _formKey = GlobalKey<FormState>();
  final _nameController = TextEditingController();
  final _emailController = TextEditingController();
  final _mobileController = TextEditingController();
  String? _gender;
  final Set<String> _hobbies = {};

  @override
  void dispose() {
    _nameController.dispose();
    _emailController.dispose();
    _mobileController.dispose();
    super.dispose();
  }

  void _submit() {
    if (!_formKey.currentState!.validate() || _gender == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please complete all required fields and select a gender.')),
      );
      return;
    }
    final details = 'Name: \${_nameController.text}\n'
        'Email: \${_emailController.text}\n'
        'Mobile: \${_mobileController.text}\n'
        'Gender: \$_gender\n'
        'Hobbies: \${_hobbies.isEmpty ? "None" : _hobbies.join(", ")}';
    showDialog<void>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Registration Details'),
        content: Text(details),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('OK')),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    const hobbies = ['Reading', 'Music', 'Gaming', 'Sports'];
    return Scaffold(
      appBar: AppBar(title: const Text('Registration Page')),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(20),
          child: Form(
            key: _formKey,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                TextFormField(
                  controller: _nameController,
                  decoration: const InputDecoration(labelText: 'Full Name', border: OutlineInputBorder()),
                  validator: (v) => v == null || v.trim().isEmpty ? 'Enter your full name' : null,
                ),
                const SizedBox(height: 14),
                TextFormField(
                  controller: _emailController,
                  keyboardType: TextInputType.emailAddress,
                  decoration: const InputDecoration(labelText: 'Email', border: OutlineInputBorder()),
                  validator: (v) => v == null || !v.contains('@') ? 'Enter a valid email' : null,
                ),
                const SizedBox(height: 14),
                TextFormField(
                  controller: _mobileController,
                  keyboardType: TextInputType.phone,
                  decoration: const InputDecoration(labelText: 'Mobile Number', border: OutlineInputBorder()),
                  validator: (v) => v == null || v.trim().length < 10 ? 'Enter a valid mobile number' : null,
                ),
                const SizedBox(height: 18),
                const Text('Gender', style: TextStyle(fontWeight: FontWeight.bold)),
                RadioListTile<String>(
                  title: const Text('Male'),
                  value: 'Male',
                  groupValue: _gender,
                  onChanged: (v) => setState(() => _gender = v),
                ),
                RadioListTile<String>(
                  title: const Text('Female'),
                  value: 'Female',
                  groupValue: _gender,
                  onChanged: (v) => setState(() => _gender = v),
                ),
                const SizedBox(height: 8),
                const Text('Hobbies', style: TextStyle(fontWeight: FontWeight.bold)),
                ...hobbies.map((hobby) => CheckboxListTile(
                  title: Text(hobby),
                  value: _hobbies.contains(hobby),
                  onChanged: (checked) => setState(() {
                    if (checked == true) {
                      _hobbies.add(hobby);
                    } else {
                      _hobbies.remove(hobby);
                    }
                  }),
                )),
                const SizedBox(height: 16),
                SizedBox(
                  width: double.infinity,
                  child: FilledButton(onPressed: _submit, child: const Text('Submit')),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
