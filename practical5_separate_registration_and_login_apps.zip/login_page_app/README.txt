# Flutter app

Open this folder in VS Code or Android Studio. Make sure Flutter is installed, then run:

```bash
flutter pub get
flutter run
```

Each app is standalone and includes its own `lib/main.dart`.
