SIMPLE LOGIN PAGE - FULL FLUTTER PROJECT

FILES:
- lib/main.dart
- lib/login_page.dart
- pubspec.yaml

RUN STEPS:
1. Extract this ZIP.
2. Open the login_page_app folder in VS Code or Android Studio.
3. Open Terminal in the project folder.
4. Run:
      flutter pub get
      flutter run

TEST LOGIN:
Username: abc
Password: 123

Correct details show "Login Successful". Incorrect details show "Invalid Login".
This is a basic practice login screen; it does not connect to a real authentication service.
